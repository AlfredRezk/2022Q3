
$(".my-slider").slick({
	dots: true,
	Infinity: true, 
	speed: 300,
  slidesToShow: 4, 
  slidesToScroll: 1, 
  autoplay: true
});


$("#dateTimeInput").datetimepicker();

var sakura = new Sakura("body");
sakura.start();


document.getElementById("bookHourBtn").addEventListener('click', validation);

function validation() { 
 // selecting DOM variables 
  const username = document.querySelector('#username');
  const lecture = document.querySelector('select');
  const instructor = document.querySelector("#lecturer");
  const dateTime = document.getElementById("dateTimeInput");

  let [date, time] = dateTime.value.split(' ');
  date = date.slice(5); 

  // validation 
  let regex = /\w{3,25}/gi;
  if (!username.value || !dateTime.value) { 
    $.notify('Please fill all form fields', 'error')
    return;
  }

  if (!regex.test(username.value)) { 
    $.notify('Username field incorrect', 'error');
    return;
  }

  let section = document.querySelector('.education article:last-child');
  let ul = section.querySelector('.box-body ul');
  let span = section.querySelector('.box-footer span');

  let li = document.createElement('li');

  li.innerHTML = `
    <span>${instructor.value} - ${date} - ${time}</span>
    <i class="fas fa-chevron-circle-right"></i>
  `;

  ul.appendChild(li);

  let num = Number(span.textContent); 
  num++;
  span.textContent = num;

  $.notify('Access Granted', 'success')
  // clear the form 
  username.value = ''; 
  dateTime.value = '';

}